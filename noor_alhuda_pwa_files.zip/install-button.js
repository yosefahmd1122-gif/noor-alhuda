(() => {
  "use strict";
  const ROOT = new URL("./", document.currentScript ? document.currentScript.src : location.href);
  const asset = (name) => new URL(name, ROOT).href;

  // Attach PWA manifest and theme metadata without changing existing sections.
  if (!document.querySelector('link[rel="manifest"]')) {
    const link = document.createElement("link");
    link.rel = "manifest";
    link.href = asset("manifest.json");
    document.head.appendChild(link);
  }
  if (!document.querySelector('meta[name="theme-color"]')) {
    const meta = document.createElement("meta");
    meta.name = "theme-color";
    meta.content = "#075e54";
    document.head.appendChild(meta);
  }

  // Register the service worker from the site subdirectory on GitHub Pages.
  if ("serviceWorker" in navigator && location.protocol === "https:") {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register(asset("service-worker.js"), { scope: ROOT.pathname })
        .catch((err) => console.warn("تعذر تسجيل Service Worker:", err));
    });
  }

  let deferredPrompt = null;
  let button = null;

  function addButton() {
    if (button || window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone) return;
    button = document.createElement("button");
    button.type = "button";
    button.id = "noor-pwa-install-button";
    button.textContent = "⬇ تثبيت التطبيق";
    button.setAttribute("aria-label", "تثبيت منصة نور الهدى كتطبيق");
    Object.assign(button.style, {
      position: "fixed",
      left: "14px",
      bottom: "18px",
      zIndex: "2147483000",
      border: "2px solid #ffffff",
      borderRadius: "999px",
      padding: "12px 17px",
      background: "linear-gradient(135deg,#1677ff,#0754c7)",
      color: "#fff",
      font: "700 15px system-ui, sans-serif",
      boxShadow: "0 5px 18px rgba(0,0,0,.28)",
      cursor: "pointer",
      animation: "noorPwaPulse 2s ease-in-out infinite"
    });
    const style = document.createElement("style");
    style.textContent = "@keyframes noorPwaPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.035)}}";
    document.head.appendChild(style);

    button.addEventListener("click", async () => {
      if (deferredPrompt) {
        deferredPrompt.prompt();
        try {
          const result = await deferredPrompt.userChoice;
          if (result && result.outcome === "accepted") button.remove();
        } catch (_) {}
        deferredPrompt = null;
        return;
      }
      // Browser fallback: explains the supported manual install path.
      const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
      const message = isIOS
        ? "لإضافة منصة نور الهدى: افتح قائمة المشاركة في Safari ثم اختر «إضافة إلى الشاشة الرئيسية»."
        : "لو لم تظهر نافذة التثبيت بعد، افتح قائمة Chrome ⋮ ثم اختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية». قد يحتاج المتصفح بعض الوقت للتعرّف على إعدادات التطبيق.";
      window.alert(message);
    });
    document.body.appendChild(button);
  }

  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    deferredPrompt = event;
    addButton();
  });
  window.addEventListener("appinstalled", () => {
    if (button) button.remove();
    button = null;
  });
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", addButton, { once: true });
  } else {
    addButton();
  }
})();
