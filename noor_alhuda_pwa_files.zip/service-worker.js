/* Noor Alhuda PWA service worker — minimal and safe */
const CACHE_NAME = "noor-alhuda-shell-v1";

self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    await self.clients.claim();
  })());
});

/* Deliberately do not intercept page/API requests:
   existing Quran, audio, Firebase and AI features keep their normal network behavior. */
